#pragma once
#include <string>
double Calculate(double a, char oper, double b);
double Calculate(char oper, double a);
double CutAndDo(std::string expression);